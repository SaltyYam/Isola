package presenter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import globals.*;

public class IsolaListener implements ActionListener
{
	/**
	 * handles the main menu 
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{	
		IsolaPresenter p = IsolaPresenter.getInstance();
		switch (IsolaPanels.valueOf(((JButton) e.getSource()).getName())) 
		{
			case GAMEPVP:
				p.startPvpGame();
				break;
			case GAMEPVE:
				p.startPveGame();
				break;
			case RETURN:
				p.returnToGame();
				break;
		default:
			break;
		}
	}

}
