package presenter;

import java.awt.Point;
import java.awt.event.ActionEvent;
import globals.*;
import view.IsolaSquare;

public class IGMPvp extends IsolaGameManager
{	
	/**
	 * handles the game loop for both players
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		IsolaSquare currentSquare;
		Point action;
		
		if (this.gameOver)
			return;
		
		// the only action performed could be by a square
		currentSquare = (IsolaSquare) e.getSource();
		action = new Point(currentSquare.getRow(), currentSquare.getCol());
		
		switch (this.moveType)
		{
			case MOVE:
				
				if (checkMove(action))	// true if move is valid
				{
					board.movePlayer(action, this.currentPlayer);
					switch (this.currentPlayer)
					{
						case PLAYER0:
							this.player0.setPlayer(IsolaPlayers.PLAYERNULL);
							currentSquare.setPlayer(IsolaPlayers.PLAYER0);
							this.setPlayer0(currentSquare);
							break;
						case PLAYER1:
							this.player1.setPlayer(IsolaPlayers.PLAYERNULL);
							currentSquare.setPlayer(IsolaPlayers.PLAYER1);
							this.setPlayer1(currentSquare);
							break;
						case PLAYERNULL:
							break;
					
					}
					currentSquare.setPlayer(this.currentPlayer);
					this.moveType = IsolaActions.BLOCK;
					IsolaPresenter.getInstance().getFrame().setActionLabel(this.moveType);
				}
				break;
				
			case BLOCK:
				if (checkBlock(action))
				{
					currentSquare.blockSquare();
					this.board.closeTile(action);
					this.moveType = IsolaActions.MOVE;
					
					if (checkWin())
						break;
					else
						switchCurrPlayer();
					IsolaPresenter.getInstance().getFrame().switchTurnLabel(this.currentPlayer);
				}
				break;			
		}
	}
	
	

}
