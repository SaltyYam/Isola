package presenter;

import globals.*;
import view.*;

public class IsolaPresenter 
{
	private static IsolaPresenter presenter = null; 
	private static IsolaFrame frame = null; 
	
	/**
	 * the private constractor for the singelton presenter object
	 */
	private IsolaPresenter()
	{
		IsolaPresenter.frame = new IsolaFrame(new IsolaListener());
	}
	
	/**
	 * inits \ returns the singelton object
	 * @return the presenter object
	 */
	public static IsolaPresenter getInstance()
	{
		if (presenter == null)
			presenter = new IsolaPresenter();
		return presenter;
	}

	/**
	 * starts the frame 
	 */
	public void startApp() 
	{
		frame.setVisible(true);
	}

	/**
	 * starts a new pvp game
	 */
	public void startPvpGame()
	{
		frame.startGame(new IGMPvp(), IsolaPanels.GAMEPVP);
		frame.showPvpPanel();
		frame.showReturnButton();
	}
	
	/**
	 * starts a new pve game
	 */
	public void startPveGame()
	{
		frame.startGame(new IGMPve(), IsolaPanels.GAMEPVE);
		frame.showPvePanel();
		frame.showReturnButton();
	}
	
	/**
	 * @return the frame object
	 */
	public IsolaFrame getFrame()
	{
		return frame;
	}

	/**
	 * return to the currently running game
	 */
	public void returnToGame() 
	{
		frame.returnToGame();
	}

	/**
	 * shows the win panel for the given player
	 * @param currentPlayer
	 */
	public void showWin(IsolaPlayers currentPlayer) 
	{
		frame.showWinPanel(currentPlayer);
		frame.hideReturnButton();
	}
	
}
