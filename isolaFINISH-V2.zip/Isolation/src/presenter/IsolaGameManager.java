package presenter;

import java.awt.Point;
import java.awt.event.ActionListener;

import globals.*;
import model.IsolaDS;
import view.IsolaSquare;

public abstract class IsolaGameManager implements ActionListener
{
	protected IsolaDS board;					// the bit board
	
	protected IsolaPlayers currentPlayer;		// current player of the game.
	protected IsolaActions moveType; 			// the current move of the player.
	
	protected IsolaSquare player0;				// the square of player 0
	protected IsolaSquare player1;				// the square of player 1
	
	protected boolean gameOver = false;			// if the gme is still on
	
	/**
	 * inits the object
	 */
	public IsolaGameManager() 
	{
		this.board = new IsolaDS();
		this.currentPlayer = IsolaPlayers.PLAYER1;
		this.moveType = IsolaActions.MOVE;
	}
	
	/**
	 * switches the current player to its opponent
	 */
	public void switchCurrPlayer()
	{
		switch (this.currentPlayer)
		{
			case PLAYER0:
				this.currentPlayer = IsolaPlayers.PLAYER1;
				break;
			case PLAYER1:
				this.currentPlayer = IsolaPlayers.PLAYER0;
				break;
			case PLAYERNULL:
				break;
		}
	}

	/**
	 * sets the player 0 square
	 * @param player0
	 */
	public void setPlayer0(IsolaSquare player0) 
	{
		this.player0 = player0;
	}

	/**
	 * sets the player 1 square
	 * @param player1
	 */
	public void setPlayer1(IsolaSquare player1) 
	{
		this.player1 = player1;
	}
	
	// 
	/**
	 * @param block
	 * @return true if block is legal 
	 */
	public boolean checkBlock(Point block) 
	{
		long bitRep = IsolaDS.convertToBit(block);
		return (this.board.getBoard() & bitRep) != 0;
	}

	/**
	 * @param move
	 * @return true if move is legal
	 */
	public boolean checkMove(Point move)
	{
		char availableMoves = this.board.availableMoves(this.currentPlayer);
		Point playerPos = this.board.getPlayer(this.currentPlayer);		
		Point relativeDirection = new Point(((int) (playerPos.getY() - move.getY())), ((int) (move.getX() - playerPos.getX())));
		char relativeDirectionBit = IsolaDS.convertDirection(relativeDirection);
		return (availableMoves & relativeDirectionBit) != 0; 
	}
	
	/**
	 * handles the win condition
	 * @return true if the game is over
	 */
	public boolean checkWin()
	{
		if (this.board.gameOver())
		{
			if (this.board.hasPlayer0Won() && this.board.hasPlayer1Won())
				this.gameWon(IsolaPlayers.PLAYERNULL);	// draw
			else if (this.board.hasPlayer0Won())
				this.gameWon(IsolaPlayers.PLAYER0);		// win
			else
				this.gameWon(IsolaPlayers.PLAYER1);
			return true;
		}
		return false;
	}
	
	/**
	 * switches screen to "game over" screen for the given player
	 * @param currentPlayer
	 */
	public void gameWon(IsolaPlayers currentPlayer) 
	{
		this.gameOver = true;
		IsolaPresenter presenter = IsolaPresenter.getInstance();
		presenter.showWin(currentPlayer);
	}

	
	
}
