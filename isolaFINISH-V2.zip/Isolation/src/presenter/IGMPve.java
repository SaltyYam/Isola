package presenter;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.util.Date;

import javax.swing.JComponent;

import globals.IsolaActions;
import globals.IsolaPanels;
import globals.IsolaPlayers;
import model.IsolaAI;
import model.IsolaAction;
import view.IsolaGamePanel;
import view.IsolaSquare;

public class IGMPve extends IsolaGameManager
{
	private IsolaAI ai = new IsolaAI();		// the AI player
	private boolean firstMove = true;		// if the first move has passed

	/**
	 * handles the game loop for the player and the ai
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		IsolaSquare currentSquare;
		Point action;
		
		if (this.gameOver)
			return;
		
		// the only action performed could be by a square
		
		if (this.firstMove && (((JComponent) e.getSource()).getName() == IsolaPanels.GAMEPVE.name()))
		{
			playAI();
			this.firstMove = false;
			IsolaPresenter.getInstance().getFrame().removeAiStart();
		}
		else
		{
			if (this.firstMove)
			{
				this.firstMove = false;
				IsolaPresenter.getInstance().getFrame().removeAiStart();
			}
	
			currentSquare = (IsolaSquare) e.getSource();
			action = new Point(currentSquare.getRow(), currentSquare.getCol());
			
			
			switch (this.moveType)
			{
				case MOVE:
					
					if (checkMove(action))	// true if move is valid
					{
						board.movePlayer(action, this.currentPlayer);
						this.player1.setPlayer(IsolaPlayers.PLAYERNULL);
						currentSquare.setPlayer(IsolaPlayers.PLAYER1);
						this.setPlayer1(currentSquare);
						
						currentSquare.setPlayer(this.currentPlayer);
						this.moveType = IsolaActions.BLOCK;
						
						IsolaPresenter.getInstance().getFrame().setActionLabel(this.moveType);
					}
					break;
					
				case BLOCK:
					if (checkBlock(action))
					{
						currentSquare.blockSquare();
						this.board.closeTile(action);
						this.moveType = IsolaActions.MOVE;
						
						if (checkWin())
							break;
						else
							switchCurrPlayer();
						
						//AI turn:
						playAI();
						
						if (checkWin())
							break;
						else
							switchCurrPlayer();
						
						IsolaPresenter.getInstance().getFrame().setActionLabel(this.moveType);		
					}
					break;			
			}
		}
	}
	
	/**
	 * plays the AI player's turn
	 */
	public void playAI()
	{
		IsolaAction bestAction; 
		IsolaSquare moveSquare;
		IsolaSquare blockSquare;
		
		// gets the best action
		bestAction = ai.getNextMove(this.board);
		
		// moves the AI player
		moveSquare = IsolaPresenter.getInstance().getFrame().getSquare(bestAction.getMove());
		board.movePlayer(bestAction.getMove(), IsolaPlayers.PLAYER0);
		this.player0.setPlayer(IsolaPlayers.PLAYERNULL);
		moveSquare.setPlayer(IsolaPlayers.PLAYER0);
		this.setPlayer0(moveSquare);
		
		// block a square
		blockSquare = IsolaPresenter.getInstance().getFrame().getSquare(bestAction.getBlock());
		blockSquare.blockSquare();
		this.board.closeTile(bestAction.getBlock());			
	}
	
}
