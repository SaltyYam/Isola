package model;

import java.awt.Point;
import java.util.*;

import globals.IsolaGameAttributes;
import globals.IsolaPlayers;
import globals.IsolaTranspositions;

public class IsolaAI 
{
	// tt
	private static HashMap<Integer, IsolaTTEntry> transTable = new HashMap<Integer, IsolaTTEntry>();
	
	// parameters for moves and maximum values
	private static final int[][] DIRECTION = {{-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}};
	private static final int[] SHIFTDIR = {7, 8, 9, 1, 7, 8, 9, 1};
	private static final int MAXCENTERDIST = 10;
	private static final int MAXMOVECOUNT = 8;
	
	// max and min values
	private static final int POS_INF = Integer.MAX_VALUE;
	private static final int NEG_INF = -Integer.MAX_VALUE;
	//
	private static final int P0_WIN = NEG_INF + 1;
	private static final int P1_WIN = POS_INF - 1;
	
	// the search depth of minimax
	private static final int SEARCH_DEPTH_BEGIN = 3;
	// middle search Depth
	private static final int SEARCH_DEPTH_MIDDLE = 5;
	
	// the percentage of the blocks on the board of the beginning stage
	private static final int BEGINNING_THRESHOLD = 15;

	// all the point offsets for the beginning points of defence
	private static final int AREAPOINTS_DEFENCE_BEGINNING = 60;
	private static final int CENTERPOINTS_DEFENCE_BEGINNING =  30;
	private static final int RELATIVEPOINTS_DEFENCE_BEGINNING =  15;
	private static final int MOVESPOINTS_DEFENCE_BEGINNING =  70;
	
	// all the point offsets for the middle points of defence
	private static final int AREAPOINTS_DEFENCE_MIDDLE = 80;
	private static final int CENTERPOINTS_DEFENCE_MIDDLE =  10;
	private static final int RELATIVEPOINTS_DEFENCE_MIDDLE =  0;
	private static final int MOVESPOINTS_DEFENCE_MIDDLE = 50;
	
	// all the point offsets for the beginning point of offence
	private static final int AREAPOINTS_OFFENCE_BEGINNING =  30;
	private static final int CENTERPOINTS_OFFENCE_BEGINNING  =  250;
	private static final int MOVESPOINTS_OFFENCE_BEGINNING  = 30;
	private static final int BLOCKMIDDDLEPOINTS_OFFENCE_BEGINNING = 50;
	
	// all the point offsets for the middle point of offence
	private static final int AREAPOINTS_OFFENCE_MIDDLE =  60;
	private static final int CENTERPOINTS_OFFENCE_MIDDLE =  30;
	private static final int MOVESPOINTS_OFFENCE_MIDDLE = 80;
	private static final int BLOCKMIDDDLEPOINTS_OFFENCE_MIDDLE = 0;
	
	/**
	 * @param board
	 * @return the best next move for player 0 (computer player)
	 */
	public IsolaAction getNextMove(IsolaDS board)
	{
		List<IsolaAction> allActions = getPossibleActions(board, IsolaPlayers.PLAYER0);
		IsolaAction bestAction = allActions.get(new Random().nextInt(allActions.size()));
		int value, bestValue = POS_INF;
		
		for (IsolaAction action : allActions)
		{
			board.playTurn(IsolaPlayers.PLAYER0, action);
			value = minimax(board, IsolaPlayers.PLAYER1, (board.precentRemovedBlocks() < BEGINNING_THRESHOLD) ? SEARCH_DEPTH_BEGIN : SEARCH_DEPTH_MIDDLE, NEG_INF, bestValue);
			board.undoTurn(IsolaPlayers.PLAYER0, action);

			if (value < bestValue)
			{
				bestValue = value;
				bestAction = action;
			}
		}
		return bestAction;
	}
	
	/**
	 * minimax algorithem to calculate the move's heuristic value - using ABP and TT
	 * @param board
	 * @param player
	 * @param depth
	 * @param alpha
	 * @param beta
	 * @return the heuristic value of the action
	 */	
	public int minimax(IsolaDS board, IsolaPlayers player, int depth, int alpha, int beta)
	{
		List<IsolaAction> allActions; 
		int eval, maxEval, minEval;
		IsolaTTEntry ttEntry = transTable.get(board.hashCode());
		
		if(ttEntry != null && ttEntry.getDepth() == depth)
		{
			if(ttEntry.getType() == IsolaTranspositions.EXACT) // stored value is exact
				return ttEntry.getEvaluation();
			if(ttEntry.getType() == IsolaTranspositions.LOWERBOUND && ttEntry.getEvaluation() > alpha)
				alpha = ttEntry.getEvaluation(); 	// update lowerbound alpha if needed
			else if(ttEntry.getType() == IsolaTranspositions.UPPERBOUND && ttEntry.getEvaluation() < beta)
				beta = ttEntry.getEvaluation(); 	// update upperbound beta if needed
			if(alpha >= beta)
				return ttEntry.getEvaluation(); 	// if lowerbound surpasses upperbound
		}
		
		if (depth == 0 || board.gameOver())
		{	
			eval = evaluteFunction(board);
			if(eval <= alpha) // a lowerbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(eval, depth, IsolaTranspositions.LOWERBOUND));
			else if(eval >= beta) // an upperbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(eval, depth, IsolaTranspositions.UPPERBOUND));
			else // a true minimax value*/
				transTable.put(board.hashCode(), new IsolaTTEntry(eval, depth, IsolaTranspositions.EXACT));
			return eval;
		}
		
	allActions = getPossibleActions(board, player);
		
		// human player
		if (player == IsolaPlayers.PLAYER1)	
		{
			maxEval = NEG_INF;
			for (IsolaAction action : allActions)
			{
				board.playTurn(player, action);
				eval = minimax(board, IsolaPlayers.PLAYER0, depth - 1, alpha, beta);
				board.undoTurn(player, action);
				
				maxEval = Math.max(maxEval, eval);
				alpha = Math.max(alpha, maxEval);
				
				if (beta <= alpha)
					break;
				
			}
			
			if(maxEval <= alpha) // a lowerbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(maxEval, depth, IsolaTranspositions.LOWERBOUND));
			else if(maxEval >= beta) // an upperbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(maxEval, depth, IsolaTranspositions.UPPERBOUND));
			else // a true minimax value*/
				transTable.put(board.hashCode(), new IsolaTTEntry(maxEval, depth, IsolaTranspositions.EXACT));
			return maxEval;
		}
		// AI player
		else	
		{
			minEval = POS_INF;
			for (IsolaAction action : allActions)
			{
				board.playTurn(player, action);
				eval = minimax(board, IsolaPlayers.PLAYER1, depth - 1, alpha, beta);
				board.undoTurn(player, action);
				
				minEval = Math.min(minEval, eval);
				beta = Math.min(beta, minEval);
				
				if (beta <= alpha)
					break;
			}
			if(minEval <= alpha) // a lowerbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(minEval, depth, IsolaTranspositions.LOWERBOUND));
			else if(minEval >= beta) // an upperbound value
				transTable.put(board.hashCode(), new IsolaTTEntry(minEval, depth, IsolaTranspositions.UPPERBOUND));
			else // a true minimax value
				transTable.put(board.hashCode(), new IsolaTTEntry(minEval, depth, IsolaTranspositions.EXACT));
			return minEval;
		}
		
	}
	
	
	/** 
	 * @param board
	 * @return the evaluation of the board
	 */
	public int evaluteFunction(IsolaDS board)
	{	
		if (board.gameOver())
			if (board.hasPlayer1Won() && board.hasPlayer0Won())
				return 0; 	// draw 
			else
				return board.hasPlayer1Won() ? P1_WIN: P0_WIN;
		else
			return evaluate(board, IsolaPlayers.PLAYER1) - evaluate(board, IsolaPlayers.PLAYER0);
	}

	/**
	 * @param board
	 * @param player
	 * @return evaluates the player's heuristic (offence + defence)
	 */
	public int evaluate(IsolaDS board, IsolaPlayers player)
	{
		return evaluateDefence(board, player) + evaluateOffence(board, player);
	}
	
	/**
	 * @param board
	 * @param player
	 * @return  the defence evaluation of the given player
	 */
	public int evaluateDefence(IsolaDS board, IsolaPlayers player)
	{
		long playerPos = IsolaDS.convertToBit(board.getPlayer(player));
		long saveBoard = board.getBoard();
		double areaSize, centerDistance, relativeDistance, currentMoveCount;
		double areaScore, centerScore, relativeScore, currentMoveScore;
		int totalScore;
		
		// calculates the blot area for the player
		board.setBoard(board.getBoard() | playerPos);	// the current position is considered 'locked'. need to open it for the search
		areaSize = evaluteArea(board, playerPos);
		board.setBoard(saveBoard);
		
		// calculates the distance from the center
		centerDistance = evaluteCenterDistance(playerPos);
		
		// calculates the distance from the other player
		relativeDistance = evaluteReletiveDistance(board);
		
		// calculates the amount of moves left
		currentMoveCount = countAvailableMoves(board.availableMoves(player));
		
		// area score calculate
		areaScore = (areaSize * 100) / ((IsolaDS.MAXBOARDSIZE));
		
		// center score calculate
		centerScore =  (MAXCENTERDIST - centerDistance);
		
		// relative score calculate
		relativeScore = (relativeDistance);
		
		// 
		currentMoveScore = currentMoveCount / 2;
		
		if (board.precentRemovedBlocks() < BEGINNING_THRESHOLD)
		{
			areaScore *= AREAPOINTS_DEFENCE_BEGINNING;
			centerScore *= CENTERPOINTS_DEFENCE_BEGINNING;
			relativeScore *= RELATIVEPOINTS_DEFENCE_BEGINNING;
			currentMoveScore *= MOVESPOINTS_DEFENCE_BEGINNING;
		}
		else
		{
			areaScore *= AREAPOINTS_DEFENCE_MIDDLE;
			centerScore *= CENTERPOINTS_DEFENCE_MIDDLE;
			relativeScore *= RELATIVEPOINTS_DEFENCE_MIDDLE;
			currentMoveScore *= MOVESPOINTS_DEFENCE_MIDDLE;
		}
		totalScore = (int) (areaScore + centerScore  + relativeScore + currentMoveScore);
		
		return totalScore;
	}
	
	/**
	 * @param board
	 * @param player
	 * @return the offence evaluation of the given player
	 */
	public int evaluateOffence(IsolaDS board, IsolaPlayers player)
	{
		long opponentPos = IsolaDS.convertToBit(board.getPlayer(getOtherPlayer(player)));
		long saveBoard = board.getBoard();
		int areaSize, centerDistance, currentMoveCount, blockCount;		// raw parameters for calculation
		int areaScore, centerScore, currentMoveScore, blockScore;		// parameters for score
		int totalScore;
		
		// calculates the blot area for the player
		board.setBoard(board.getBoard() | opponentPos);	// the current position is considered 'locked'. need to open it for the search
		areaSize = evaluteArea(board, opponentPos);
		board.setBoard(saveBoard);
		
		// calculates the distance from the center
		centerDistance = evaluteCenterDistance(opponentPos);
		
		// calculates the amount of moves left
		currentMoveCount = countAvailableMoves(board.availableMoves(getOtherPlayer(player)));
		
		// calculates block value
		blockCount = evaluteBlockPosition(board, player);
		
		// area score calculate
		areaScore = ((IsolaDS.MAXBOARDSIZE - areaSize) * 100)/ IsolaDS.MAXBOARDSIZE;
		
		// center score calculate
		centerScore = (centerDistance); 
			
		// move score calculate
		currentMoveScore = (MAXMOVECOUNT - currentMoveCount);
		
		// block score calculate
		blockScore =  blockCount;
		
		if (board.precentRemovedBlocks() < BEGINNING_THRESHOLD)
		{
			areaScore *= AREAPOINTS_OFFENCE_BEGINNING;
			centerScore *= CENTERPOINTS_OFFENCE_BEGINNING;
			currentMoveScore *= MOVESPOINTS_OFFENCE_BEGINNING;
			blockScore *= BLOCKMIDDDLEPOINTS_OFFENCE_BEGINNING;
		}
		else
		{
			areaScore *= AREAPOINTS_OFFENCE_MIDDLE;
			centerScore *= CENTERPOINTS_OFFENCE_MIDDLE;
			currentMoveScore *= MOVESPOINTS_OFFENCE_MIDDLE;
			blockScore *= BLOCKMIDDDLEPOINTS_OFFENCE_MIDDLE;
		}
		
		
		totalScore = areaScore + centerScore  + currentMoveScore + blockScore;
	
		return totalScore;
	}
	
	/**
	 * @param board
	 * @param player
	 * @return the block position evaluation for the current player
	 */
	public int evaluteBlockPosition(IsolaDS board, IsolaPlayers player)
	{
		int wallCount = 0;
		switch (player) {
			case PLAYER0:
				wallCount += (countAvailableMoves((char) ((~board.availableMoves(IsolaPlayers.PLAYER1)) & 0x14)));
				break;
			case PLAYER1:
				wallCount += (countAvailableMoves((char) ((~board.availableMoves(IsolaPlayers.PLAYER0)) & 0x41)));
				break;
			default:
			break;
		}
		
		switch (player) {
		case PLAYER0:
			wallCount += 2 * (countAvailableMoves((char) ((~board.availableMoves(IsolaPlayers.PLAYER1)) & 0x08)));
			break;
		case PLAYER1:
			wallCount += 2 * (countAvailableMoves((char) ((~board.availableMoves(IsolaPlayers.PLAYER0)) & 0x80)));
			break;
		default:
			break;
		}
		return wallCount;
	}
	
	/**
	 * @param board
	 * @param currPos
	 * @return the area evaluation for the current player
	 */
	public int evaluteArea(IsolaDS board, long currPos)
	{
		int moveCount = 0;
		int indexPos = IsolaDS.convertToIndex(currPos);
		char availableMoves = 0;
		char mask = 0x07;
		char idMask = 0x02;
		
		if ((board.getBoard() & currPos) == 0)
			return 0; 
		
		board.setBoard(board.getBoard() & (~currPos));
		
		for (int i = 0 ; i < 4 ; i++)
			availableMoves |= ((currPos >> SHIFTDIR[i]) & board.getBoard()) != 0 ? (1 << i) : 0; 
			
		for (int i = 4 ; i < 8 ; i++)
			availableMoves |= ((currPos << SHIFTDIR[i]) & board.getBoard()) != 0 ? (1 << i) : 0; 
			
		// the left column
		if (indexPos % 8 == 7)
			availableMoves &= 0x3E; // 0 0 1 1 1 1 1 0
		// the right column
		if (indexPos % 8 == 0)
			availableMoves &= 0xE3; // 1 1 1 0 0 0 1 1
		
		//the top row
		if (indexPos / 8 == 0)
			availableMoves &= 0xF8;	// 1 1 1 1 1 0 0 0
		
		//the bottom row (not needed because of extra byte in the long parameter, here for completion)
		if (indexPos / 8 == 6)
			availableMoves &= 0x8F;	// 1 0 0 0 1 1 1 1
		
		for (int i = 0 ; i < 8 ; i++)
		{
			availableMoves = (char) (((availableMoves << 1) & 0xFF) | (availableMoves >>> 7)); // rotation left by one
			if ((availableMoves & mask) == idMask)
				availableMoves ^= idMask; 
		}
		
		for (int i = 0 ; i < 4 ; i++)
			if ((availableMoves & (1 << i)) != 0 && ((currPos >> SHIFTDIR[i]) & board.getBoard()) != 0)
				moveCount += 1 + evaluteArea(board, currPos >> SHIFTDIR[i]);
		
		for (int i = 4 ; i < 8 ; i++)
			if ((availableMoves & (1 << i)) != 0 && ((currPos << SHIFTDIR[i]) & board.getBoard()) != 0)
				moveCount += 1 + evaluteArea(board, currPos << SHIFTDIR[i]);
			
		return moveCount;
		 
	}
	
	/**
	 * @param player
	 * @return the oppnent player
	 */
	public static IsolaPlayers getOtherPlayer(IsolaPlayers player)
	{
		switch (player)
		{
			case PLAYER0:
				return IsolaPlayers.PLAYER1;
			case PLAYER1:
				return IsolaPlayers.PLAYER0;
			case PLAYERNULL:
				break;
		}
		return IsolaPlayers.PLAYERNULL;
	}
	
	/** 
	 * @param currPos
	 * @return the center distance of the current position
	 */
	public int evaluteCenterDistance(long currPos)
	{
		int distance = 0;
		int indexPos = IsolaDS.convertToIndex(currPos);
		int indexRow = indexPos / 8, indexCol = indexPos % 8;
		
		if (indexRow == 0 || indexRow == (IsolaGameAttributes.ROWS - 1))
			distance += 5;
		else if (indexRow == 1 || indexRow == (IsolaGameAttributes.ROWS - 2))
			distance += 2;
		else if (indexRow == 2 || indexRow == (IsolaGameAttributes.ROWS - 3))
			distance += 1;
		
		if (indexCol == 0 || indexCol == (IsolaGameAttributes.COLS - 1))
			distance += 5;
		else if (indexCol == 1 || indexCol == (IsolaGameAttributes.COLS - 2))
			distance += 2;
		else if (indexCol == 2 || indexCol == (IsolaGameAttributes.COLS - 3))
			distance += 1;
		
		return distance;
	}
	
	/**
	 * @param board
	 * @return  the distance between the two players
	 */
	public double evaluteReletiveDistance(IsolaDS board)
	{	
		return board.getPlayer0().distance(board.getPlayer1());
	}
	
	/** 
	 * @param availableMoves
	 * @return the amount of aviliable moves
	 */
	public int countAvailableMoves(char availableMoves)
	{
		int count = 0;
		while (availableMoves != 0)
		{
			count++;
			availableMoves &= (availableMoves - 1);
		}
		
		return count;
	}
	
	/**
	 * @param board
	 * @param player
	 * @return a list of all possible moves for the current player
	 */
	public List<Point> getPossibleMoves(IsolaDS board, IsolaPlayers player)
	{
		ArrayList<Point> possibleMoves = new ArrayList<Point>();
		char availableMoves = board.availableMoves(player);
		Point currentPosition = board.getPlayer(player);
		
		for (int i = 0 ; i < 8 ; i++)
			if ((availableMoves & (1 << i)) != 0)
				possibleMoves.add(new Point ((int) (currentPosition.getX() + DIRECTION[i][0]), (int) (currentPosition.getY() + DIRECTION[i][1])));
		
		return possibleMoves;
	}
	
	/**
	 * @param board
	 * @param player
	 * @return a list of point for all possible block for the current player
	 */
	public List<Point> getPossibleBlocks(IsolaDS board, IsolaPlayers player)
	{
		return getPossibleMoves(board, getOtherPlayer(player));
		
		/*
		ArrayList<Point> possibleBlocks = new ArrayList<Point>();
		Point opponentPosition = board.getPlayer(getOtherPlayer(player));
		long bitBoard = board.getBoard();
		long pos = 1;
		int index;
		
		for (long i = 0; i < 64 ; i++)
		{
			if ((bitBoard & pos) != 0)
			{
				index = IsolaDS.convertToIndex(pos);
				Point block = new Point (index / 8, index % 8);
				if (block.distance(opponentPosition) <= 2.5)
					possibleBlocks.add(block);
				
			}
			pos <<= 1;
		}
		
		return possibleBlocks;
		*/
	}
	
	/**
	 * @param board
	 * @param player
	 * @return a list of all the possible actions of the player
	 */
	public List<IsolaAction> getPossibleActions(IsolaDS board, IsolaPlayers player)
	{
		ArrayList<IsolaAction> possibleActions = new ArrayList<IsolaAction>();
		
		Point currentPos = board.getPlayer(player);
		List<Point> possibleMoves = getPossibleMoves(board, player);
		List<Point> possibleBlocks = getPossibleBlocks(board, player); 
		
		for (Point move : possibleMoves)
			for (Point block : possibleBlocks)
				if (!move.equals(block)) // dont move and block the same square
					possibleActions.add(new IsolaAction(currentPos, move, block));
		
		// moves and blocks the previous position
		for (Point move : possibleMoves)
			possibleActions.add(new IsolaAction(currentPos, move, currentPos));
		
		Collections.shuffle(possibleActions);	// randomizes the actions for efficiency 
		return possibleActions;
	}
}
