package model;

import java.awt.Point;
import java.util.Objects;

import globals.IsolaGameAttributes;
import globals.IsolaPlayers;

public class IsolaDS
{
	public static final long ONE = 1;
	
	private long board;					// bits used for 7*8 board. on bits are open squares, off bits are closed squares.
	private long player0; 				// only one bit is on, on bit is player0's position 
	private long player1;				// only one bit is on, on bit is player1's position
	
	public static final int MAXBOARDSIZE =  IsolaGameAttributes.ROWS * IsolaGameAttributes.COLS - 2;
	
	/**
	 * inits the board 
	 */
	public IsolaDS()
	{	
		/* board (on bits are players)
		 * 
		 * 1111 1111 - 0
		 * 1111 1111 - 1
		 * 1111 1111 - 2
		 * 1111 1111 - 3 
		 * 1111 1111 - 4
		 * 1111 1111 - 5
		 * 1111 1111 - 6
		 * 0000 0000 - not used
		 */
		this.board = -ONE >>> 8; 	
		
		
		
		/* board (on bits are players)
		 * 
		 * 1111 1111 - 0
		 * 1111 1111 - 1
		 * 1111 1111 - 2
		 * 0111 1110 - 3 
		 * 1111 1111 - 4
		 * 1111 1111 - 5
		 * 1111 1111 - 6
		 * 0000 0000 - not used
		*/
		this.player0 = (ONE << (8 * 3));			// starts from mid right		
		this.player1 = (ONE << ((8 * 3) + 7));		// starts from mid left
		
		// flips the player bits in the board
		this.board &= ~this.player0;
		this.board &= ~this.player1;
	}
	
	/**
	 * closes the tile of the board
	 * @param tile
	 * @return true
	 */
	public boolean closeTile(Point tile)
	{
		this.board &= ~convertToBit(tile);
		return true;
	}
	
	/**
	 * opens the tile on the board
	 * @param tile
	 * @return true
	 */
	public boolean openTile(Point tile)
	{
		this.board |= convertToBit(tile);
		return true;
	}
	
	/**
	 * moves the given player to the new position
	 * @param newPlayerPos
	 * @param player
	 * @return true
	 */
	public boolean movePlayer(Point newPlayerPos, IsolaPlayers player)
	{
		long newPlayerPosMask = convertToBit(newPlayerPos);
		this.board &= ~newPlayerPosMask;
		if (player == IsolaPlayers.PLAYER0)
		{
			this.board |= this.player0;
			this.player0 = newPlayerPosMask;
		}
		else // player == IsolaPlayers.PLAYER1
		{
			this.board |= this.player1;
			this.player1 = newPlayerPosMask;
		}
		return true;
		
	}
	
	/**
	 * plays a turn - moves and block
	 * @param player
	 * @param action
	 */
	public void playTurn(IsolaPlayers player, IsolaAction action)
	{
		movePlayer(action.getMove(), player);
		closeTile(action.getBlock());
	}
	
	/**
	 * undos a turn - moves back and un-blocks
	 * @param player
	 * @param action
	 */
	public void undoTurn(IsolaPlayers player, IsolaAction action)
	{
		openTile(action.getBlock());
		movePlayer(action.getCurrentPos(), player);
	}
	
	/**
	 * @return true if player 0 won
	 */
	public boolean hasPlayer0Won()
	{
		return availableMoves(IsolaPlayers.PLAYER1) == 0;
	}
	
	/**
	 * @return true if player 1 won
	 */
	public boolean hasPlayer1Won()
	{
		return availableMoves(IsolaPlayers.PLAYER0) == 0;
	}
	
	/**
	 * @param player
	 * @return true if the given player won
	 */
	public boolean hasPlayerWon(IsolaPlayers player)
	{
		if (player == IsolaPlayers.PLAYER0)
			return hasPlayer0Won();
		else
			return hasPlayer1Won();
	}
	
	/**
	 * @return true if one of the players won
	 */
	public boolean gameOver()
	{
		return hasPlayer0Won() || hasPlayer1Won();
	}
	
	/**
	 * @param player
	 * @return a direction char for the 8 available moves the of the given player
	 */
	public char availableMoves(IsolaPlayers player)
	{
		char directions = 0; // each on bit is a direction that the current player can move to
		long currentPlayer;
		int bitPlayer = 0;
		
		// current player is a long parameter with only 1 bit that is on, log of this parameter is the position of the bit
		if (player == IsolaPlayers.PLAYER0)
			currentPlayer = this.player0;
		else
			currentPlayer = this.player1;
		
		bitPlayer = (int) (Math.log(currentPlayer) / Math.log(2));
		
		/* directions:
		 * 0 0 0
		 * 0   0
		 * 0 0 0
		 */
		
		int[] dirNums = {7, 8, 9, 1, 7, 8, 9, 1};
		
		for (int i = 0 ; i < 4 ; i++)
			directions |= ((currentPlayer >> dirNums[i]) & this.board) != 0 ? (1 << i) : 0; 
			
		for (int i = 4 ; i < 8 ; i++)
			directions |= ((currentPlayer << dirNums[i]) & this.board) != 0 ? (1 << i) : 0; 
		
		// the left column
		if (bitPlayer % 8 == 7)
			directions &= 0x3E; // 0 0 1 1 1 1 1 0
		// the right column
		if (bitPlayer % 8 == 0)
			directions &= 0xE3; // 1 1 1 0 0 0 1 1
		
		//the top row
		if (bitPlayer / 8 == 0)
			directions &= 0xF8;	// 1 1 1 1 1 0 0 0
		
		//the bottom row (not needed because of extra byte in the long parameter, here for completion)
		if (bitPlayer / 8 == 6)
			directions &= 0x8F;	// 1 0 0 0 1 1 1 1
		
		return directions;
	}
	
	/**
	 * @param direction
	 * @return a char of the direction bit of the given point
	 */
	public static char convertDirection(Point direction)
	{	
		if (direction.getX() == -1 && direction.getY() == -1)
			return 0x01;
		
		if (direction.getX() == 0 && direction.getY() == -1)
			return 0x02;
		
		if (direction.getX() == 1 && direction.getY() == -1)
			return 0x04;
		
		if (direction.getX() == 1 && direction.getY() == 0)
			return 0x08;
		
		if (direction.getX() == 1 && direction.getY() == 1)
			return 0x10;
		
		if (direction.getX() == 0 && direction.getY() == 1)
			return 0x20;
		
		if (direction.getX() == -1 && direction.getY() == 1)
			return 0x40;
		
		if (direction.getX() == -1 && direction.getY() == 0)
			return 0x80;
		
		return 0;
	}
	
	/**
	 * 
	 * @param point
	 * @return the bit position of the given point
	 */
	public static long convertToBit(Point point)
	{
		return (ONE << (long) ((point.getX() * 8) + point.getY()));
	}
	
	/**
	 * @param bitPos
	 * @return  the tile index of the given bit position
	 */
	public static int convertToIndex(long bitPos)
	{
		return (int) (Math.log(bitPos) / Math.log(2));
	}
	
	/**
	 * @param player
	 * @return the point of the given player
	 */
	public Point getPlayer(IsolaPlayers player)
	{
		/**
		 * return  
		 * gets a player
		 */
		if (player == IsolaPlayers.PLAYER0)
			return getPlayer0();
		else
			return getPlayer1();
	}
	
	/**
	 * @return the point of player 0
	 */
	
	public Point getPlayer0() 
	{
		int bitPlayer = convertToIndex(this.player0);
		return new Point(bitPlayer / 8, bitPlayer % 8);
	}

	/**
	 * @return the point of player 1
	 */
	public Point getPlayer1() 
	{
		int bitPlayer = convertToIndex(this.player1);
		return new Point(bitPlayer / 8, bitPlayer % 8);
	}
	
	/**
	 * @return the bit board
	 */
	public long getBoard() 
	{
		return board;
	}
	
	/**
	 * @param board
	 */
	public void setBoard(long board)
	{
		this.board = board;
	}
	
	/**
	 * @return the presentage of blocked tiles on the board
	 */
	public int precentRemovedBlocks()
	{
		long board = this.board;
		int count = 0;
		while (board != 0)
		{
			count++;
			board &= (board - 1);
		}
		
		return (int) (((MAXBOARDSIZE - count) / ((double) (MAXBOARDSIZE))) * 100);
	}

	@Override
	public int hashCode() {
		return Objects.hash(board, player0, player1);
	}
}
