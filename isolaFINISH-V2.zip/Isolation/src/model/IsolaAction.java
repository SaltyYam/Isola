package model;

import java.awt.Point;

public class IsolaAction 
{
	private Point currentPos;		// the current position point a the player
	private Point move;				// the move point parameter
	private Point block;			// the block point parameter
	
	/**
	 * initializes the object
	 * @param currentPos
	 * @param move
	 * @param block
	 */
	public IsolaAction(Point currentPos, Point move, Point block)
	{
		this.currentPos = currentPos;
		this.move = move;
		this.block = block;
	}
	
	/** 
	 * @return the current position of the object
	 */
	public Point getCurrentPos() 
	{
		return currentPos;
	}

	/**
	 * sets the current position parameter
	 * @param currentPos
	 */
	public void setCurrentPos(Point currentPos)
	{
		this.currentPos = currentPos;
	}
	
	/**
	 * @return the point of move
	 */
	public Point getMove() 
	{
		return move;
	}
	
	/**
	 * sets the move point
	 * @param move
	 */
	public void setMove(Point move) 
	{
		this.move = move;
	}

	/**
	 * @return the block point
	 */
	public Point getBlock()
	{
		return block;
	}
	
	/**
	 * sets the block point
	 * @param block
	 */
	public void setBlock(Point block) 
	{
		this.block = block;
	}
	
	@Override
	/**
	 * @return the string of the object
	 */
	public String toString() 
	{
		return "IsolaAction [move=" + move + ", block=" + block + "]";
	}
}
