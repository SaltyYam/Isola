package model;

import globals.IsolaTranspositions;

public class IsolaTTEntry 
{
	private int evaluation;
	private int depth;
	private IsolaTranspositions type;
	
	/**
	 * inits the object
	 * @param evaluation
	 * @param depth
	 * @param type
	 */
	public IsolaTTEntry(int evaluation, int depth, IsolaTranspositions type) 
	{
		this.evaluation = evaluation;
		this.depth = depth;
		this.type = type;
	}

	
	/**
	 * @return the evaluation
	 */
	public int getEvaluation() {
		return evaluation;
	}

	/**
	 * @param evaluation the evaluation to set
	 */
	public void setEvaluation(int evaluation) {
		this.evaluation = evaluation;
	}

	/**
	 * @return the depth
	 */
	public int getDepth() {
		return depth;
	}

	/**
	 * @param depth the depth to set
	 */
	public void setDepth(int depth) {
		this.depth = depth;
	}
	

	/**
	 * @return the type
	 */
	public IsolaTranspositions getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(IsolaTranspositions type) {
		this.type = type;
	}
}

	
