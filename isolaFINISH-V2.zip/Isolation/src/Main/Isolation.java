package Main;

import presenter.IsolaPresenter;

public class Isolation 
{
	
    public static void main(String[] args)
    {	
    	IsolaPresenter.getInstance().startApp();
    }
}