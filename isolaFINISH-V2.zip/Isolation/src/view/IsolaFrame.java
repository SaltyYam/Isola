package view;

import java.awt.CardLayout;
import java.awt.Point;
import java.awt.event.ActionListener;
import globals.*;
import presenter.IsolaGameManager;

import javax.swing.*;

@SuppressWarnings("serial")
public class IsolaFrame extends JFrame
{
	// all the layouts and the panel of the game
	private CardLayout cardLayout;			
	private JPanel framePanel;
	private IsolaMainPanel mainPanel;
	private IsolaGamePanel gamePanel;
	
	private IsolaPanels currentPanel;
	private IsolaPanels currentGamePanel;
	
	/**
	 * inints the frame object
	 * @param mainListner
	 */
	public IsolaFrame(ActionListener mainListner)
	{
		
		this.setTitle("Isolation");
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.setSize(IsolaGameAttributes.SQUARELEN * (IsolaGameAttributes.COLS + 2), IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.ROWS);
		this.setResizable(false);
		
		this.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) 
		    {
		        if (currentPanel != IsolaPanels.MAIN)
		        {
		            showMainPanel();
		        }
		        else
		        	System.exit(0);
		    }});
		
		this.cardLayout = new CardLayout();
		this.framePanel = new JPanel(this.cardLayout);
		
		this.mainPanel = new IsolaMainPanel(mainListner);
		
		this.setIconImage(IsolaGameAttributes.GAMEICON.getImage());
		
		this.setLayout(new CardLayout());
		
		
		this.framePanel.add(IsolaPanels.MAIN.name(), this.mainPanel);
		
		this.add(framePanel);
	}
	
	/**
	 * shoes the main panel
	 */
	public void showMainPanel() 
	{
		this.cardLayout.show(this.framePanel, IsolaPanels.MAIN.name());
		this.currentPanel = IsolaPanels.MAIN;
	}
	
	/**
	 * shows the pvp panel
	 */
	public void showPvpPanel()
	{
		this.cardLayout.show(this.framePanel, IsolaPanels.GAMEPVP.name());
		this.currentPanel = IsolaPanels.GAMEPVP;
	}
	
	/**
	 * shows the pve panel
	 */
	public void showPvePanel()
	{
		this.cardLayout.show(this.framePanel, IsolaPanels.GAMEPVE.name());
		this.currentPanel = IsolaPanels.GAMEPVE;
	}
	
	/**
	 * shows the win panel for the given player
	 * @param player
	 */
	public void showWinPanel(IsolaPlayers player) 
	{
		this.gamePanel.setWinner(player);
	}
	
	/**
	 * switches the turn label to the given player
	 * @param player
	 */
	public void switchTurnLabel(IsolaPlayers player)
	{
		this.gamePanel.switchTurn(player);
	}
	
	/**
	 * switches the action label for the given action
	 * @param action
	 */
	public void setActionLabel(IsolaActions action)
	{
		this.gamePanel.setAction(action);
	}
	
	/**
	 * @param point
	 * @return the square of the given point
	 */
	public IsolaSquare getSquare(Point point)
	{
		return this.gamePanel.getSquare(point);
	}

	/**
	 * starts a new game 
	 * @param gameManager
	 * @param gameType
	 */
	public void startGame(IsolaGameManager gameManager, IsolaPanels gameType) 
	{
		if (this.gamePanel != null)
			this.framePanel.remove(this.gamePanel);
		
		this.gamePanel = new IsolaGamePanel(gameManager);
		this.currentGamePanel = gameType;
		
		this.framePanel.add(gameType.name(), this.gamePanel);
	}

	/**
	 * returns the the running game
	 */
	public void returnToGame() 
	{
		switch (this.currentGamePanel) 
		{
			case GAMEPVP:
				this.showPvpPanel();
				break;
			case GAMEPVE:
				this.showPvePanel();
			default:
				break;
		}
	}
	
	/**
	 * shows the return-to-game button
	 */
	public void showReturnButton()
	{
		this.mainPanel.showReturnButton();
	}
	
	/**
	 * hides the return-to-game button
	 */
	public void hideReturnButton()
	{
		this.mainPanel.hideReturnButton();
	}
	
	/**
	 * remove the ai start button from the game panel
	 */
	public void removeAiStart()
	{
		this.gamePanel.removeAiStart();
	}

}
