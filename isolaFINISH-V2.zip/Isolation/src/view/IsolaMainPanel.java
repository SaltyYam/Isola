package view;

import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import globals.*;

@SuppressWarnings("serial")
public class IsolaMainPanel extends JPanel
{
	JButton startPvpGame; 
	JButton startPveGame;
	JButton returnToGame;
	
	/**
	 * inits the main panel
	 * @param l
	 */
	public IsolaMainPanel(ActionListener l)
	{		
		//	this.setLayout(new BorderLayout());
		
		this.setBackground(IsolaGameAttributes.MAINCOLOR);
		
		this.startPvpGame = new JButton("Start new PVP Game");
		this.startPvpGame.setBounds(0, 0, globals.IsolaGameAttributes.SQUARELEN * 2, globals.IsolaGameAttributes.SQUARELEN);
		this.startPvpGame.setFont(IsolaGameAttributes.TEXTFONT);
		this.startPvpGame.setName(IsolaPanels.GAMEPVP.name());
		this.startPvpGame.setFocusable(false);
		
		this.startPveGame = new JButton("Start new PVE Game");
		this.startPveGame.setBounds(0, 0, globals.IsolaGameAttributes.SQUARELEN * 2, globals.IsolaGameAttributes.SQUARELEN);
		this.startPveGame.setFont(IsolaGameAttributes.TEXTFONT);
		this.startPveGame.setName(IsolaPanels.GAMEPVE.name());
		this.startPveGame.setFocusable(false);
		
		this.returnToGame = new JButton("Return to Game");
		this.returnToGame.setBounds(0, 0, globals.IsolaGameAttributes.SQUARELEN * 2, globals.IsolaGameAttributes.SQUARELEN);
		this.returnToGame.setFont(IsolaGameAttributes.TEXTFONT);
		this.returnToGame.setName(IsolaPanels.RETURN.name());
		this.returnToGame.setFocusable(false);
		this.returnToGame.setVisible(false);
		
		
		this.startPvpGame.addActionListener(l);
		this.startPveGame.addActionListener(l);
		this.returnToGame.addActionListener(l);
		
		this.add(startPvpGame);
		this.add(startPveGame);
		this.add(returnToGame);
		
		this.setVisible(true);
	}
	
	/**
	 * shows the return-to-game button
	 */
	public void showReturnButton()
	{
		this.returnToGame.setVisible(true);
	}
	
	/**
	 * hides the return-to-game button
	 */
	public void hideReturnButton()
	{
		this.returnToGame.setVisible(false);
	}
	
}
