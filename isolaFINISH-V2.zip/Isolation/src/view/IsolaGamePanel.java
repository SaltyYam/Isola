package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import globals.*;
import presenter.IGMPve;
import presenter.IsolaGameManager;

@SuppressWarnings("serial")
public class IsolaGamePanel extends JPanel implements ActionListener
{	
	private JPanel gamePanel;
	private JPanel infoPanel;
	private IsolaSquare[][] squareGrid;
	
	private JLabel player;
	private JLabel actionLabel;
	
	private JButton returnButton;
	private JButton aiStart;
	
	/**
	 * inits the game panel object
	 * @param gameMananger
	 */
	public IsolaGamePanel(IsolaGameManager gameMananger)
	{
		this.squareGrid = new IsolaSquare[IsolaGameAttributes.ROWS][IsolaGameAttributes.COLS];
		
		// one row, two columns
		this.setLayout(new GridBagLayout());
		this.setBackground(IsolaGameAttributes.MAINCOLOR);
		
		this.gamePanel = new JPanel(new GridLayout(IsolaGameAttributes.ROWS, IsolaGameAttributes.COLS, 0, 0));
		gamePanel.setBounds(0, 0, IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.COLS, IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.ROWS);
		gamePanel.setSize(new Dimension(IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.COLS, IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.ROWS));
		
		
		this.infoPanel = new JPanel(new GridLayout(4, 1, 0, 0));
		this.infoPanel.setBackground(IsolaGameAttributes.MAINCOLOR);
		this.infoPanel.setSize(new Dimension(IsolaGameAttributes.SQUARELEN * 2, IsolaGameAttributes.SQUARELEN * IsolaGameAttributes.ROWS));
		
		// action lables
		this.player = new JLabel();
		this.player.setFont(IsolaGameAttributes.TEXTFONT);
		
		this.actionLabel = new JLabel();
		this.actionLabel.setFont(IsolaGameAttributes.TEXTFONT);
		this.actionLabel.setForeground(IsolaGameAttributes.TEXTCOLOR);
		
		switchTurn(IsolaPlayers.PLAYER1);
		
		this.returnButton = new JButton("Return to main menu");
		this.returnButton.setSize(100, 50);
		this.returnButton.addActionListener(this);
		this.returnButton.setFocusable(false);
		
		this.infoPanel.add(this.player);
		this.infoPanel.add(this.actionLabel);
		this.infoPanel.add(this.returnButton);
		
		// adds only if the game in pve
		if (gameMananger.getClass() == IGMPve.class)
		{
			this.aiStart = new JButton("Let AI start");
			this.aiStart.setSize(100, 50);
			this.aiStart.addActionListener(gameMananger);
			this.aiStart.setFocusable(false);
			
			this.aiStart.setName(IsolaPanels.GAMEPVE.name());
			
			this.infoPanel.add(this.aiStart);
		}
		
		for (int row = 0 ; row < IsolaGameAttributes.ROWS  ; row++)
		{
			for (int col = (IsolaGameAttributes.COLS - 1) ; col >= 0 ; col--)
			{
				this.squareGrid[row][col] = new IsolaSquare(row, col, gameMananger);
				gamePanel.add(this.squareGrid[row][col]);
				
				// player 0 starts in the middle row, on column 0
				if (row == (IsolaGameAttributes.ROWS / 2)  &&  col == 0)
				{
					this.squareGrid[row][col].setPlayer(IsolaPlayers.PLAYER0);
					gameMananger.setPlayer0(this.squareGrid[row][col]);
				}
				// player 1 starts in the middle row, on the last column
				if (row == (IsolaGameAttributes.ROWS / 2) && col == (IsolaGameAttributes.COLS - 1))
				{
					this.squareGrid[row][col].setPlayer(IsolaPlayers.PLAYER1);
					gameMananger.setPlayer1(this.squareGrid[row][col]);
				}
			}
		}
		
		
		this.add(gamePanel);
		this.add(infoPanel);
		
	}

	/**
	 * listens to the return-to-menu button 
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		JComponent comp = (JComponent) e.getSource();
		Window win = SwingUtilities.getWindowAncestor(comp);
		win.dispatchEvent(new WindowEvent(win, WindowEvent.WINDOW_CLOSING));
	}
	
	/**
	 * sets the action label
	 * @param act
	 */
	public void setAction(IsolaActions act)
	{
		this.actionLabel.setText(act.name().toLowerCase() + "!");
	}
	
	/**
	 * switches the turn player to the given player
	 * @param player
	 */
	public void switchTurn(IsolaPlayers player)
	{
		setAction(IsolaActions.MOVE);
		
		switch (player) 
		{
			case PLAYER0:
				this.player.setText("Orange");
				this.player.setForeground(IsolaGameAttributes.PLAYERORANGE);
				break;
			
			case PLAYER1:
				this.player.setText("Green");
				this.player.setForeground(IsolaGameAttributes.PLAYERGREEN);
				break;
			case PLAYERNULL:
				break;
		}
	}
	
	/**
	 * @param point
	 * @return the square of the given point
	 */
	public IsolaSquare getSquare(Point point)
	{
		if (point.getX() < 0 || point.getX() >= IsolaGameAttributes.ROWS  || point.getY() < 0 || point.getY() >= IsolaGameAttributes.COLS)
			return null;
		
		return this.squareGrid[(int) point.getX()][(int) point.getY()];
	}
	
	
	/**
	 * changes the winner to the given player
	 * @param player
	 */
	public void setWinner(IsolaPlayers player)
	{
		this.actionLabel.setText("has won the game!");
		switch (player) 
		{
			case PLAYER0:
				this.player.setText("Orange");
				this.player.setForeground(IsolaGameAttributes.PLAYERORANGE);
				break;
			case PLAYER1:
				this.player.setText("Green");
				this.player.setForeground(IsolaGameAttributes.PLAYERGREEN);
				break;
			case PLAYERNULL:
				this.player.setText("Draw!");
				this.player.setForeground(IsolaGameAttributes.TEXTCOLOR);	// not necessary 
				this.actionLabel.setText("Everyone got stranded!");
				break;
		}
	}
	
	/**
	 * remove the AI start button from the screen
	 */
	@SuppressWarnings("deprecation")
	public void removeAiStart() 
	{
		this.aiStart.hide();
		this.infoPanel.remove(this.aiStart);
	}
}
