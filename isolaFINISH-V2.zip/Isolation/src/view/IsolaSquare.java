package view;

import java.awt.event.ActionListener;
import globals.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class IsolaSquare extends JButton
{
	
	private int row;
	private int col;
	
	/**
	 * inits the object
	 * @param rowIndex
	 * @param colIndex
	 * @param l
	 */
	public IsolaSquare(int rowIndex, int colIndex, ActionListener l)
	{
		this.row = rowIndex;
		this.col = colIndex;
		
		this.setBackground(IsolaGameAttributes.OPENCOLOR);
		this.setOpaque(true);
		
		this.setHorizontalAlignment(JButton.CENTER);
		this.setVerticalAlignment(JButton.CENTER);
		
		this.setFocusable(false);
		
		this.setBorder(BorderFactory.createLineBorder(IsolaGameAttributes.BORDERCOLOR, 5));
		
		this.addActionListener(l);
		
	}
	
	/**
	 * blocks the square
	 */
	public void blockSquare()
	{
		this.setBackground(IsolaGameAttributes.CLOSECOLOR);
		this.setEnabled(false);
	}
	
	/**
	 * sets the icon to the given player
	 * @param player
	 */
	public void setPlayer(IsolaPlayers player)
	{
		switch (player)
		{
			case PLAYER0:
				this.setIcon(IsolaGameAttributes.PLAYER0);
				break;
			case PLAYER1:
				this.setIcon(IsolaGameAttributes.PLAYER1);
				break;
			case PLAYERNULL:
				this.setIcon(null);
				break;
		}
	}
	
	/**
	 * @return the row of the square
	 */
	public int getRow() 
	{
		return row;
	}

	/**
	 * @return the column of the square
	 */
	public int getCol() 
	{
		return col;
	}
	

}
