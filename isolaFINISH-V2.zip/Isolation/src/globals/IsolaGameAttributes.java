package globals;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;

public interface IsolaGameAttributes 
{
	// isola square length
	int SQUARELEN = 70;
	
	// matrix attributes
	int ROWS = 7;
	int COLS = 8;
	
	// games colors
	Color OPENCOLOR = new Color(0xA8ACED);
	Color CLOSECOLOR = new Color(0x454661);
	Color BORDERCOLOR = new Color(0x7274A1);
	Color MAINCOLOR = new Color(0x9195ED);
	Color TEXTCOLOR = Color.black;
	
	// font
	Font TEXTFONT = new Font("Monospaced", Font.BOLD, 20);
	
	// player icons
	ImageIcon PLAYER0 = new ImageIcon("player0.png");
	ImageIcon PLAYER1 = new ImageIcon("player1.png");
	
	// player colors
	Color PLAYERORANGE = new Color(0xFFB27F);
	Color PLAYERGREEN = new Color(0xC8FEB1);
	
	// app icon
	ImageIcon GAMEICON = new ImageIcon("gameIcon.png");
	
	
	
}
