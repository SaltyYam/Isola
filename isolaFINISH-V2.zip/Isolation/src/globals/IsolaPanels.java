package globals;

public enum IsolaPanels 
{
	MAIN,
	GAMEPVP,
	GAMEPVE,
	RETURN,
	WIN,
	RULES
}
