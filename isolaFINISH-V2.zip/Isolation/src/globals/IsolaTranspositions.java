package globals;

public enum IsolaTranspositions 
{
	EXACT,
	UPPERBOUND,
	LOWERBOUND
}
