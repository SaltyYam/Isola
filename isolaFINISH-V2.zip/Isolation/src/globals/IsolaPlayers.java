package globals;

public enum IsolaPlayers 
{
	PLAYER0,
	PLAYER1,
	PLAYERNULL
}
