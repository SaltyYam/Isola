package globals;

public enum IsolaActions 
{
	MOVE,
	BLOCK
}
